package com.example.inventoryappcinnamongeorge;

public @interface InjectView {
}
