package com.example.inventoryappcinnamongeorge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Messaging extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging);
    }
}